#include "ShapeGame.h"

#include <iostream>

#include "Texture.h"
#include "ShapeGameActor.h"
#include "MeshComponent.h"
#include "ModelMesh.h"
#include "Renderer.h"
#include "SpriteComponent.h"
#include "MoveComponent.h"
#include "PositionalLightComponent.h"
#include "AmbientLightComponent.h"
#include "DirectionalLightComponent.h"
#include "SpotLightComponent.h"
#include "CubeMesh.h"
#include "SphereMesh.h"
#include "CylinderMesh.h"
#include "ConeMesh.h"
#include "GameBoardMesh.h"
#include "CameraComponent.h"
#include "ReparentComponent.h"
#include "SoundListenerComponent.h"
#include "SoundSourceComponent.h"
#include "SoundReverbZoneComponent.h"

#include "RigidBodyComponent.h"


#include "InputComponent.h"

ShapeGame::ShapeGame( )
	:Game( "CSE387 - Final Project")
{
}


void ShapeGame::LoadData( )
{
	// Setup lights in the scene
	ShapeGame::SetupLighting();

	//first camera
	ShapeGameActor* cam1act = new ShapeGameActor (this);
	cam1act->SetPosition (vec3(6,-30,-50),WORLD);
	cam1act->SetRotation (glm::rotate(glm::radians(90.0f),vec3(1,0,0)));
	CameraComponent* cam1 = new CameraComponent (cam1act);
	cam1->setDepth (0);
	cam1->setViewPort (0,0,0.5,1);

	InputComponent* camin = new InputComponent (cam1act);
	camin->setAll (SDL_SCANCODE_UP,SDL_SCANCODE_DOWN,SDL_SCANCODE_RIGHT,SDL_SCANCODE_LEFT,SDL_SCANCODE_W,SDL_SCANCODE_S,SDL_SCANCODE_D,SDL_SCANCODE_A);

	//second camera
	ShapeGameActor* cam2act = new ShapeGameActor (this);
	cam2act->SetPosition (vec3 (6, 60, -50),WORLD);
	cam2act->SetRotation (glm::rotate(glm::radians (-90.0f),vec3(1,0,0)));
	cam2act->SetRotation (cam2act->GetRotation()  * glm::rotate(glm::radians(180.0f),cam2act->GetFacingDirection()));
	CameraComponent* cam2 = new CameraComponent (cam2act);
	cam2->setDepth (1);
	cam2->setViewPort (0.5, 0, 0.5, 1);


	// Sun
	mSunActor = new ShapeGameActor(this);
	mSunActor->SetPosition(vec3(10, -1, -50));
	
	Material sunMat;
	sunMat.setDiffuseTexture( this->GetRenderer( )->GetTexture( "Assets/sunmap.jpg" )->GetTextureObject( ) );

	SphereMesh * sunMesh = new SphereMesh(2.0f);
	sunMesh->Load("earth sphere", sunMat);

	MeshComponent * sunMeshComponent = new MeshComponent(mSunActor, sunMesh);

	RigidBodyComponent * rg = new RigidBodyComponent( mSunActor, sunMeshComponent,1, DYNAMIC );
	

	// Earth
	mEarthActor = new ShapeGameActor (this);
	mEarthActor->SetPosition (vec3 (20, 3, -51));

	Material earthMat;
	earthMat.setDiffuseTexture (this->GetRenderer ()->GetTexture ("Assets/earthmap.jpg")->GetTextureObject ());

	SphereMesh * earthMesh = new SphereMesh (2.0f);
	earthMesh->Load ("earth sphere", earthMat);

	MeshComponent * earthMeshComponent = new MeshComponent (mEarthActor, earthMesh);

	RigidBodyComponent * rge = new RigidBodyComponent (mEarthActor, earthMeshComponent, 1, DYNAMIC);


	// Moon
	mMoonActor = new ShapeGameActor (this);
	mMoonActor->SetPosition (vec3 (25, 3, -51));

	Material moonMat;
	moonMat.setDiffuseTexture (this->GetRenderer ()->GetTexture ("Assets/moonmap.jpg")->GetTextureObject ());

	SphereMesh * moonMesh = new SphereMesh (2.0f);
	moonMesh->Load ("moon sphere", moonMat);

	MeshComponent * moonMeshComponent = new MeshComponent (mMoonActor, moonMesh);

	RigidBodyComponent * rgm = new RigidBodyComponent (mMoonActor, moonMeshComponent, 1, DYNAMIC);


	

	// Empty Solar System Actor (root of the scene graph), where the ambient sound lay
	ShapeGameActor * emptyActor = new ShapeGameActor(this);
	emptyActor->SetPosition(vec3(0, 0, -20));

	



	SoundSourceComponent* ambient = new SoundSourceComponent (emptyActor,"Assets/imperial_march.wav",FLT_MAX,FLT_MAX,FMOD_SPEAKERMODE_MONO);
	
	

	// Model
	Actor  * mModelActor = new ShapeGameActor( this );
	mModelActor->SetPosition( vec3( -6, 0, -50 ) );
	

	ModelMesh * modelMesh = new ModelMesh( );
	modelMesh->Load( this->mRenderer, "Assets/an-imperial-star-destroyer/source/ISD.blend" );

	MeshComponent * modelMeshComponent = new MeshComponent( mModelActor, modelMesh );

	 RigidBodyComponent * rg3 = new RigidBodyComponent( mModelActor, modelMeshComponent, 500, DYNAMIC );

	 rg3->setVelocity (vec3 (1, 0, 0));

	 
	 SoundSourceComponent* ship = new SoundSourceComponent (mModelActor,"Assets/AMBrom.wav");

	

	
	

	SoundListenerComponent * listComp = new SoundListenerComponent( cam1act );
	SoundReverbZoneComponent * reverb = new SoundReverbZoneComponent( cam1act );



	// Add actors to the scene graph
	this->AddChild( cam1act );
	this->AddChild (cam2act);
	this->AddChild (mSunActor);
	this->AddChild( mModelActor );
	
	ambient->play (true);
	ship->play (true);
}

void ShapeGame::SetupLighting()
{
	//ambient light
	ShapeGameActor * ambLightActor = new ShapeGameActor( this );
	ambLightActor->SetPosition( vec3( 0.0f, 0.0f, 0.0f ) );
	AmbientLightComponent * ambLightComp = new AmbientLightComponent( ambLightActor, GL_LIGHT_ZERO, true );
	ambLightComp->setAmbientColor( vec4( 0.15f, 0.15f, 0.15f, 1.0f ) );

	//positional Light
	ShapeGameActor * posLightActor = new ShapeGameActor( this );
	posLightActor->SetPosition( vec3( 5.0f, 10.0f, -10.0f ) );
	PositionalLightComponent * posLightComp = new PositionalLightComponent( posLightActor, GL_LIGHT_ONE, false );
	posLightComp->setDiffuseColor( vec4( 1.0f, 1.0f, 1.0f, 1.0f ) );
	posLightComp->setSpecularColor( vec4( 1.0f, 1.0f, 1.0f, 1.0f ) );

	//directional Light
	ShapeGameActor * dirLightActor = new ShapeGameActor( this );
	dirLightActor->SetRotation( glm::rotate( glm::radians( 45.0f ), vec3( 0, 1, 0 ) ) * glm::rotate( glm::radians( -45.0f ), vec3( 1, 0, 0 ) ) );
	//set rotation
	DirectionalLightComponent * dirLightComp = new DirectionalLightComponent( dirLightActor, GL_LIGHT_TWO, true );
	dirLightComp->setDiffuseColor( vec4( 0.75f, 0.75f, 0.75f, 1.0f ) );
	dirLightComp->setSpecularColor( vec4( 1.0f, 1.0f, 1.0f, 1.0f ) );

	// spot light
	ShapeGameActor *spotLightActor = new ShapeGameActor( this );
	spotLightActor->SetPosition( vec3( 0.0f, 0.0f, 0.0f ) );
	SpotLightComponent *spotLightComp = new SpotLightComponent( spotLightActor, GL_LIGHT_THREE, false );
	spotLightComp->setDiffuseColor( vec4( 0.75f, 0.75f, 0.75f, 1.0f ) );
	spotLightComp->setSpecularColor( vec4( 1.0f, 1.0f, 1.0f, 1.0f ) );
	spotLightComp->setSpotCutoffCos( glm::cos( glm::radians( 10.0f ) ) );
	spotLightComp->setSpotExponent( 2 );

} // end setupLighting


