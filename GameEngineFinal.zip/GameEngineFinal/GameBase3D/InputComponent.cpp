// ----------------------------------------------------------------
// From Game Programming in C++ by Sanjay Madhav
// Copyright (C) 2017 Sanjay Madhav. All rights reserved.
// 
// Released under the BSD License
// See LICENSE in root directory for full details.
// ----------------------------------------------------------------

#include "InputComponent.h"
#include "Actor.h"

InputComponent::InputComponent(class Actor* owner)
:MoveComponent(owner)
{
	mForwardKey = 0;
	mBackKey = 0;
	mRightKey =0;
	mLeftKey = 0;
	mMoveForwardKey = 0;
	mMoveBackKey = 0;
	mMoveRightKey = 0;
	mMoveLeftKey = 0;
}


void InputComponent::setAll (int fwd, int bck, int r, int l, int mfwd, int mbck, int mr, int ml) 
{
	mForwardKey = fwd; 
	mBackKey = bck; 
	mRightKey = r; 
	mLeftKey = l;
	mMoveForwardKey = mfwd; 
	mMoveBackKey = mbck; 
	mMoveRightKey = mr; 
	mMoveLeftKey = ml;
}

void InputComponent::Update (float deltaTime)
{
	vec3 upLoc = mOwner->GetUpDirection (WORLD);
	vec3 side = glm::cross (mOwner->GetFacingDirection (WORLD), mOwner->GetUpDirection (WORLD));
	mat4 rot = mOwner->GetRotation (WORLD);


	const uint8_t* keyState = keys;

	if (keyState[mForwardKey])
	{
		mOwner->SetRotation (mOwner->GetRotation (LOCAL)*glm::rotate (glm::radians (deltaTime*30.0f), RIGHT));
		//mOwner->SetRotation ((deltaTime*30.0f)*glm::rotate (glm::radians (1.0f), side)* rot, WORLD);
	}
	if (keyState[mBackKey])
	{
		mOwner->SetRotation (mOwner->GetRotation (LOCAL)*glm::rotate (glm::radians (deltaTime*30.0f), -RIGHT));
		//mOwner->SetRotation ((deltaTime*30.0f)*glm::rotate (glm::radians (-1.0f), side)* rot, WORLD);
	}
	if (keyState[mRightKey])
	{
		mOwner->SetRotation (mOwner->GetRotation (LOCAL)*glm::rotate (glm::radians (deltaTime*30.0f), -UP));
		//mOwner->SetRotation ((deltaTime*30.0f)*glm::rotate (glm::radians (-1.0f), upLoc)* rot, WORLD);
	}
	if (keyState[mLeftKey])
	{
		mOwner->SetRotation (mOwner->GetRotation (LOCAL)*glm::rotate (glm::radians (deltaTime*30.0f), UP));
		//mOwner->SetRotation ((deltaTime*30.0f)*glm::rotate (glm::radians (1.0f), upLoc)* rot, WORLD);
	}
	if (keyState[mMoveForwardKey])
	{
		mOwner->SetPosition (mOwner->GetPosition (WORLD) + (mOwner->GetFacingDirection (WORLD))*(deltaTime*30.0f), WORLD);
	}
	if (keyState[mMoveBackKey])
	{
		mOwner->SetPosition (mOwner->GetPosition (WORLD) - mOwner->GetFacingDirection (WORLD)*(deltaTime*30.0f), WORLD);
	}
	if (keyState[mMoveRightKey])
	{
		mOwner->SetPosition (mOwner->GetPosition (WORLD) + side * (deltaTime*30.0f), WORLD);
	}
	if (keyState[mMoveLeftKey])
	{
		mOwner->SetPosition (mOwner->GetPosition (WORLD) - side * (deltaTime*30.0f), WORLD);
	}

}


void InputComponent::ProcessInput(const uint8_t* keyState)
{
	keys = keyState;


	/*vec3 upLoc = mOwner->GetUpDirection (WORLD);
	vec3 side = glm::cross (mOwner->GetFacingDirection(WORLD),mOwner->GetUpDirection(WORLD));
	mat4 rot = mOwner->GetRotation (WORLD);

	
	if (keyState[mForwardKey])
	{
		mOwner->SetRotation (glm::rotate(glm::radians(1.0f),side)* rot,WORLD);
	}
	if (keyState[mBackKey])
	{
		mOwner->SetRotation (glm::rotate (glm::radians (-1.0f), side)* rot, WORLD);
	}
	if (keyState[mRightKey])
	{
		mOwner->SetRotation (glm::rotate (glm::radians(-1.0f),upLoc)* rot, WORLD);
	}
	if (keyState[mLeftKey])
	{
		mOwner->SetRotation (glm::rotate (glm::radians (1.0f), upLoc)* rot, WORLD);
	}
	if (keyState[mMoveForwardKey])
	{
		mOwner->SetPosition (mOwner->GetPosition(WORLD)+mOwner->GetFacingDirection(WORLD),WORLD);
	}
	if (keyState[mMoveBackKey])
	{
		mOwner->SetPosition (mOwner->GetPosition (WORLD) - mOwner->GetFacingDirection (WORLD),WORLD);
	}
	if (keyState[mMoveRightKey])
	{
		mOwner->SetPosition (mOwner->GetPosition (WORLD) + side, WORLD);
	}
	if (keyState[mMoveLeftKey])
	{
		mOwner->SetPosition (mOwner->GetPosition (WORLD) - side, WORLD);
	}*/

	
}



