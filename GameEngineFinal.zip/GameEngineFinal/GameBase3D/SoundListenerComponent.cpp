#include "SoundListenerComponent.h"


SoundListenerComponent::SoundListenerComponent( Actor* owner )
	:SoundBaseComponent( owner )
{
}


void SoundListenerComponent::Update( float deltaTime )
{
	/**
	Velocity is only required if you want doppler effects. Otherwise you can
	pass 0 or nullptr to both System::set3DListenerAttributes and Channel::set3DAttributes
	for the velocity parameter, and no doppler effect will be heard.

	The velocity passed to FMOD Studio is meters per second and not meters per frame.
	*/

	// Calculate the World position and orientation 
	SoundBaseComponent::Update( deltaTime );
	if (dopler)
	{
		SoundEngine::HandleError (SoundEngine::system->set3DListenerAttributes (
			0, &fmod_pos, &fmod_vel, &fmod_forward, &fmod_up));
	}
	else
	{
		SoundEngine::HandleError (SoundEngine::system->set3DListenerAttributes (
			0, &fmod_pos, 0, &fmod_forward, &fmod_up));
	}

} // end soundUpdate
